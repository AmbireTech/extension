import CopyIcon from './CopyIcon'

export default CopyIcon
